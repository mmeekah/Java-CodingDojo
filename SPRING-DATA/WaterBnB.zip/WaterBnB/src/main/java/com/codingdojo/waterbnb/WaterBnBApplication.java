package com.codingdojo.waterbnb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaterBnBApplication {

	public static void main(String[] args) {
		SpringApplication.run(WaterBnBApplication.class, args);
	}

}
