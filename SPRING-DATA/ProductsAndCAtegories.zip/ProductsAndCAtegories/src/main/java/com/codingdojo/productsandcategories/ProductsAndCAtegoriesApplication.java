package com.codingdojo.productsandcategories;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsAndCAtegoriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductsAndCAtegoriesApplication.class, args);
	}

}
