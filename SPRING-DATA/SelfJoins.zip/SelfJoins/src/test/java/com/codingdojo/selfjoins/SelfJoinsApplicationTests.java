package com.codingdojo.selfjoins;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SelfJoinsApplicationTests {

	@Test
	void contextLoads() {
	}

}
