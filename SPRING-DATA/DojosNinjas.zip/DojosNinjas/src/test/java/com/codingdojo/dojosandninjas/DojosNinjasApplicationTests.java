package com.codingdojo.dojosandninjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojosNinjasApplicationTests {

	@Test
	void contextLoads() {
	}

}
