package com.codingdojo.admindash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminDashApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminDashApplication.class, args);
	}

}
