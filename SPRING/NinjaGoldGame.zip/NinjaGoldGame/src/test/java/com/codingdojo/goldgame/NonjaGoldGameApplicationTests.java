package com.codingdojo.goldgame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NonjaGoldGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
